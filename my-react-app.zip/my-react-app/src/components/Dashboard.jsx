import { useState } from "react";
import Navbar from "./Navbar";
import JobList from "./JobList";
import JobForm from "./JobForm";

function Dashboard() {
  const [jobs, setJobs] = useState([
    { id: 1, title: "Frontend Developer", company: "ABC" },
    { id: 2, title: "Backend Developer", company: "XYZ" }
  ]);

  const addJob = (job) => {
    setJobs([...jobs, job]);
  };

  return (
    <div>
      <Navbar title="Job Portal" />
      <JobForm addJob={addJob} />
      <JobList jobs={jobs} />
    </div>
  );
}

export default Dashboard;