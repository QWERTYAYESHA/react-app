function Navbar({ setPage }) {
  return (
    <div style={{ display: "flex", gap: "20px", padding: "10px" }}>
      <button onClick={() => setPage("home")}>Home</button>
      <button onClick={() => setPage("jobs")}>Jobs</button>
      <button onClick={() => setPage("dashboard")}>Dashboard</button>
    </div>
  );
}

export default Navbar;