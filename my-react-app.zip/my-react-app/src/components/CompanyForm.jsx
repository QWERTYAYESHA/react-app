import { useState } from "react";

function CompanyForm() {
  const [company, setCompany] = useState("");
  const [role, setRole] = useState("");
  const [submitted, setSubmitted] = useState(null);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!company || !role) {
      alert("All fields required");
      return;
    }

    setSubmitted({ company, role });
    setCompany("");
    setRole("");
  };

  return (
    <div>
      <h2>Company Interest Form</h2>

      <form onSubmit={handleSubmit}>
        <input
          placeholder="Company Name"
          value={company}
          onChange={(e) => setCompany(e.target.value)}
        />

        <input
          placeholder="Job Role"
          value={role}
          onChange={(e) => setRole(e.target.value)}
        />

        <button type="submit">Submit</button>
      </form>

      {submitted && (
        <p>
          Submitted: {submitted.company} - {submitted.role}
        </p>
      )}
    </div>
  );
}

export default CompanyForm;