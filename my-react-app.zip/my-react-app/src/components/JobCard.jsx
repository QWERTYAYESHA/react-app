function JobCard({ job }) {
  return (
    <div style={{ border: "1px solid gray", margin: "10px", padding: "10px" }}>
      <h3>{job.title}</h3>
      <p>{job.company}</p>
      <p>{job.category}</p>
    </div>
  );
}

export default JobCard;