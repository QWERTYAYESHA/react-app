import { useState } from "react";

function JobForm({ addJob }) {
  const [title, setTitle] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    addJob({ id: Date.now(), title });
    setTitle("");
  };

  return (
    <form onSubmit={handleSubmit}>
      <input 
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        placeholder="Enter job"
      />
      <button type="submit">Add</button>
    </form>
  );
}

export default JobForm;