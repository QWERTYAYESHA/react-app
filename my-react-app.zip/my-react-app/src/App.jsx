import CompanyForm from "./components/CompanyForm";
import StudentForm from "./components/StudentForm";
import JobList from "./components/JobList";

function App() {
  return (
    <div>
      <h1>Job Fair Portal</h1>

      <StudentForm />
      <CompanyForm />
      <JobList />
    </div>
  );
}

export default App;