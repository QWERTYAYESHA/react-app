const jobsData = [
  { id: 1, title: "Frontend Developer", company: "Google", category: "IT" },
  { id: 2, title: "Backend Developer", company: "Amazon", category: "IT" },
  { id: 3, title: "HR Manager", company: "Meta", category: "HR" },
];

export default jobsData;