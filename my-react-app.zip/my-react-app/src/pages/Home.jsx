import StudentForm from "../components/StudentForm";

function Home() {
  return (
    <div>
      <h1>Job Fair Portal</h1>
      <StudentForm />
    </div>
  );
}

export default Home;