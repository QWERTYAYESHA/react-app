function Dashboard() {
  return (
    <div>
      <h2>Admin Dashboard</h2>
      <p>Manage jobs, companies, and applications</p>
    </div>
  );
}

export default Dashboard;