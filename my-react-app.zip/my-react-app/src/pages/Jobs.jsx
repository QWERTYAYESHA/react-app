import JobList from "../components/JobList";

function Jobs() {
  return (
    <div>
      <JobList />
    </div>
  );
}

export default Jobs;